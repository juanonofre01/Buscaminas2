/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.buscaminas;

import com.mycompany.buscaminas.VentanaPrincipal;

/**
 *
 * @author PC
 */
public class BuscaMinas {

    public static void main(String[] args) {
        
        VentanaPrincipal v = new VentanaPrincipal();
        v.setVisible(true);
    }
}
